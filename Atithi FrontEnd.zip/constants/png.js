import alertno from "../assets/alertno.png"
export default {
    alertno
}