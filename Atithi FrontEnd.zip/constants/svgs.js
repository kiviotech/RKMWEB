import alert from "../assets/SVG/alert.svg";
import dots from "../assets/SVG/dots.svg";
import notification from "../assets/SVG/notification.svg";
import profile from "../assets/SVG/profile.svg";
export default {
    alert,
    dots,
    notification,
    profile,
}