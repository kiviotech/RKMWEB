import { create } from "zustand";

const initialDonorDetails = {
  title: 'Sri',
  name: '',
  phoneCode: '+91',
  phone: '',
  email: '',
  mantraDiksha: '',
  identityType: '',
  identityNumber: '',
  roomNumber: '',
  pincode: '',
  houseNumber: '',
  streetName: '',
  district: '',
  state: ''
};

export const useDonationStore = create((set) => ({
  donations: {
    receipts: []
  },
  addDonation: (receipt) => set((state) => {
    const currentReceipts = state.donations?.receipts || [];
    
    // Find existing donor group
    const donorGroupIndex = currentReceipts.findIndex(group => 
      Array.isArray(group) && 
      group.length > 0 && 
      (group[0].donorDetails?.guestId === receipt.donorDetails?.guestId ||
       group[0].donorId === receipt.donorId)
    );

    let newReceipts;
    if (donorGroupIndex >= 0) {
      // Update existing donor group
      newReceipts = [...currentReceipts];
      const existingGroup = newReceipts[donorGroupIndex];
      const existingReceiptIndex = existingGroup.findIndex(r => r.type === receipt.type);
      
      if (existingReceiptIndex >= 0) {
        // Update existing receipt
        existingGroup[existingReceiptIndex] = receipt;
      } else {
        // Add new receipt to group
        existingGroup.push(receipt);
      }
    } else {
      // Add new donor group
      newReceipts = [
        ...currentReceipts,
        [receipt]
      ];
    }

    return {
      donations: {
        ...state.donations,
        receipts: newReceipts
      }
    };
  }),
  updateDonorDetails: (receiptNumber, details) => set((state) => {
    const updatedReceipts = (state.donations?.receipts || []).map(group =>
      Array.isArray(group) ? group.map(receipt =>
        receipt.receiptNumber === receiptNumber
          ? { ...receipt, donorDetails: details }
          : receipt
      ) : []
    );

    return {
      donations: {
        ...state.donations,
        receipts: updatedReceipts
      }
    };
  }),
  clearDonations: () => set({
    donations: { receipts: [] }
  }),
}));
